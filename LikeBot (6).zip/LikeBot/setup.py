from setuptools import setup

setup(
    name="discord-bot-freefire",
    version="1.0.0",
    description="Discord Bot for Free Fire API Integration",
    py_modules=["main", "config", "logger"],
    install_requires=[
        "discord.py>=2.5.2",
        "aiohttp>=3.12.15",
    ],
    python_requires=">=3.11",
)