import os

# Discord Bot Configuration
BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN", "your_bot_token_here")

# Channel Configuration
# IMPORTANTE: Substitua pelo ID do canal onde o bot deve enviar as notificações diárias
# Para obter o ID do canal: Ative o Modo Desenvolvedor no Discord, clique com botão direito no canal e "Copiar ID"
NOTIFICATION_CHANNEL_ID = int(os.getenv("NOTIFICATION_CHANNEL_ID", "1234567890123456789"))

# Free Fire API Configuration
API_BASE_URL = "https://likes.ffgarena.cloud/api/v2/likes"
API_AUTH_TOKEN = "wipp-7"

# Logging Configuration
LOG_LEVEL = os.getenv("LOG_LEVEL", "WARNING")  # Reduced logging to save memory
LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"  # Simplified format
