# Discord Bot for Free Fire API Integration

## Overview

This is a Discord bot designed to integrate with Free Fire gaming services through API calls. The bot manages user registrations by linking Discord users with their Free Fire game IDs and provides automated notifications through Discord channels. The system includes user data persistence, logging capabilities, and scheduled task execution for sending automatic likes to registered Free Fire IDs.

## Recent Changes (August 11, 2025)

✅ **Complete Discord Bot Implementation**
- Created slash command `/botlike` with admin-only access (only title and description required)
- Implemented customizable embed panels with title, description, hex color, and optional image
- Added interactive button system with modal forms for Free Fire ID registration
- Built duplicate ID prevention system
- Created JSON-based data persistence for user registrations
- Implemented 24-hour automated task for sending 100 likes per registered ID
- Added `/configcanal` command to dynamically set notification channel
- Added `/testeapi` command to test API responses and view player information
- Added `/limparcache` command for manual cache cleanup
- Enhanced daily reports to include player information from API responses
- Implemented automatic cache cleanup before and after daily tasks
- Added comprehensive error handling and logging
- Successfully connected to Discord and tested all functionality
- Authorized specific admin ID (794343189896232971) for bot management
- API integration confirmed working with player data display
- Fixed Square Cloud deployment structure conflicts
- Created clean package structure with setup.py and squarecloud.config
- Reorganized files to prevent build errors on deployment platforms
- Optimized memory usage with reduced Discord intents and logging
- Limited message cache to 50 messages and simplified log format
- Reduced Square Cloud memory requirement from 256MB to 128MB
- Implemented comprehensive ticket system with payment integration
- Added "Liberar Acesso" button to existing panel creating private tickets
- Created 4-button ticket interface: Ver Chave Pix, Colocar Descrição, Fechar Ticket, Configurar Chave Pix
- Added access control system requiring liberation before Free Fire ID registration
- Implemented /liberar command for admin user management
- Added auto-delete ticket functionality after 5 hours of inactivity

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Framework
- **Discord.py Library**: Uses the discord.py library with command extensions for building the Discord bot interface
- **Command System**: Implements a command-based interaction model with the '!' prefix for user commands
- **Intents Configuration**: Enables message content intents to allow the bot to read and respond to user messages

### Data Management
- **JSON File Storage**: Uses local JSON file storage (`data/registrations.json`) for persisting user registration data
- **Registration System**: Maps Discord user IDs to Free Fire game IDs with duplicate prevention
- **Data Persistence**: Implements automatic data loading and saving with error handling

### API Integration
- **Free Fire API**: Integrates with the Free Fire Garena API (`https://likes.ffgarena.cloud/api/v2/likes`) 
- **Authentication**: Uses token-based authentication with a predefined auth token ("wipp-7")
- **Asynchronous HTTP**: Utilizes aiohttp for non-blocking API requests

### Logging and Monitoring
- **Multi-level Logging**: Implements configurable logging with both console and file output
- **Log Management**: Stores logs in a dedicated logs directory with UTF-8 encoding
- **Error Tracking**: Comprehensive error handling and logging throughout the application

### Task Scheduling
- **Discord Tasks Extension**: Uses discord.ext.tasks for scheduling periodic operations
- **Notification System**: Automated notifications sent to configured Discord channels
- **Asynchronous Operations**: Non-blocking task execution to maintain bot responsiveness

### Configuration Management
- **Environment Variables**: Configuration through environment variables with fallback defaults
- **Centralized Config**: Single configuration file managing all bot settings including tokens, channels, and API endpoints

## External Dependencies

### Discord Platform
- **Discord Bot API**: Primary platform for bot deployment and user interaction
- **Discord Channels**: Specific notification channels for automated messaging
- **Discord Authentication**: Bot token authentication for Discord API access

### Free Fire Gaming Service
- **Free Fire Garena API**: External gaming API for retrieving player statistics and game data
- **API Authentication**: Token-based authentication system for API access
- **Game ID System**: Integration with Free Fire's player identification system

### Python Libraries
- **discord.py**: Discord API wrapper and bot framework
- **aiohttp**: Asynchronous HTTP client for API requests
- **asyncio**: Asynchronous programming support for concurrent operations

### Infrastructure
- **File System**: Local JSON file storage for user registration data
- **Logging System**: File-based logging with configurable levels and formatting