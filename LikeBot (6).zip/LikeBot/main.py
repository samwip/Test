import discord
from discord.ext import commands, tasks
import asyncio
import aiohttp
import json
import os
from datetime import datetime, timedelta
from config import BOT_TOKEN, API_BASE_URL, API_AUTH_TOKEN
from logger import setup_logger

# Setup logging
logger = setup_logger()

# Bot setup with optimized intents
intents = discord.Intents.default()
intents.message_content = True
intents.presences = False
intents.typing = False
intents.voice_states = False
intents.members = False
bot = commands.Bot(
    command_prefix='!',
    intents=intents,
    case_insensitive=True,
    strip_after_prefix=True,
    max_messages=50  # Limit message cache to reduce memory
)

# Data file paths
DATA_FILE = 'data/registrations.json'
CONFIG_FILE = 'data/bot_config.json'
USERS_FILE = 'data/users.json'

# Configuration variables
PIX_CHAVE = "exemplo@email.com"  # Chave Pix padrão - pode ser alterada pelo comando
ADMIN_ID = 794343189896232971  # ID do administrador autorizado
TICKET_AUTO_DELETE_HOURS = 5  # Tempo para auto-delete dos tickets

class BotConfig:
    def __init__(self):
        self.config = self.load_config()

    def load_config(self):
        """Load bot configuration from JSON file"""
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return {
                "notification_channel_id": None,
                "pix_key": PIX_CHAVE,
                "released_users": []
            }
        except Exception as e:
            logger.error(f"Error loading config: {e}")
            return {
                "notification_channel_id": None,
                "pix_key": PIX_CHAVE,
                "released_users": []
            }

    def save_config(self):
        """Save bot configuration to JSON file"""
        try:
            os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
            with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Error saving config: {e}")

    def set_notification_channel(self, channel_id):
        """Set notification channel ID"""
        self.config["notification_channel_id"] = channel_id
        self.save_config()

    def get_notification_channel(self):
        """Get notification channel ID"""
        return self.config.get("notification_channel_id")

    def set_pix_key(self, pix_key):
        """Set PIX key"""
        self.config["pix_key"] = pix_key
        self.save_config()

    def get_pix_key(self):
        """Get PIX key"""
        return self.config.get("pix_key", PIX_CHAVE)

    def add_released_user(self, user_id):
        """Add user to released users list"""
        if "released_users" not in self.config:
            self.config["released_users"] = []
        if user_id not in self.config["released_users"]:
            self.config["released_users"].append(user_id)
            self.save_config()

    def is_user_released(self, user_id):
        """Check if user is released"""
        return user_id in self.config.get("released_users", [])

    def remove_released_user(self, user_id):
        """Remove user from released users list"""
        if "released_users" not in self.config:
            self.config["released_users"] = []
        if user_id in self.config["released_users"]:
            self.config["released_users"].remove(user_id)
            self.save_config()

class RegistrationData:
    def __init__(self):
        self.data = self.load_data()

    def load_data(self):
        """Load registration data from JSON file"""
        try:
            if os.path.exists(DATA_FILE):
                with open(DATA_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    logger.info(f"Loaded {len(data)} registrations from {DATA_FILE}")
                    # Ensure all existing registrations are in list format
                    for user_id, ff_ids in data.items():
                        if isinstance(ff_ids, str):
                            data[user_id] = [ff_ids]
                    return data
            else:
                logger.info(f"No registration file found at {DATA_FILE}, starting with empty data")
                return {}
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            return {}

    def save_data(self):
        """Save registration data to JSON file"""
        try:
            os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
            with open(DATA_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, indent=2, ensure_ascii=False)
                logger.info(f"Saved {len(self.data)} registrations to {DATA_FILE}")
        except Exception as e:
            logger.error(f"Error saving data: {e}")

    def register_user(self, user_id, ff_id):
        """Register a user with their Free Fire ID"""
        # Check if FF ID already exists for any user
        for registered_user_id, registered_ids in self.data.items():
            # Handle both old format (single ID) and new format (list of IDs)
            if isinstance(registered_ids, str):
                if registered_ids == ff_id:
                    return False, "Este ID do Free Fire já está cadastrado."
            elif isinstance(registered_ids, list):
                if ff_id in registered_ids:
                    return False, "Este ID do Free Fire já está cadastrado."

        # Initialize user data if doesn't exist
        if str(user_id) not in self.data:
            self.data[str(user_id)] = []

        # Convert old format (single string) to new format (list) if needed
        if isinstance(self.data[str(user_id)], str):
            self.data[str(user_id)] = [self.data[str(user_id)]]

        # Add new ID to user's list
        self.data[str(user_id)].append(ff_id)
        self.save_data()

        ids_count = len(self.data[str(user_id)])
        return True, f"ID cadastrado com sucesso! Você agora tem {ids_count} ID(s) cadastrado(s)."

    def get_all_registrations(self):
        """Get all registered Free Fire IDs"""
        return self.data

# Global instances
bot_config = BotConfig()
registration_data = RegistrationData()

# Ensure data directories exist
os.makedirs('data', exist_ok=True)
os.makedirs('logs', exist_ok=True)

class FreFireIDModal(discord.ui.Modal, title='Cadastro de ID do Free Fire'):
    def __init__(self):
        super().__init__()

    ff_id = discord.ui.TextInput(
        label='Seu ID do Free Fire',
        placeholder='Digite seu ID do Free Fire aqui...',
        required=True,
        max_length=50
    )

    async def on_submit(self, interaction: discord.Interaction):
        try:
            user_id = interaction.user.id
            ff_id = self.ff_id.value.strip()

            if not ff_id:
                await interaction.response.send_message(
                    "❌ Por favor, insira um ID válido do Free Fire.",
                    ephemeral=True
                )
                return

            success, message = registration_data.register_user(user_id, ff_id)

            if success:
                # Remove user from released users list after successful registration
                bot_config.remove_released_user(user_id)

                embed = discord.Embed(
                    title="✅ Cadastro Realizado",
                    description=f"Seu ID **{ff_id}** foi cadastrado com sucesso!\n\nVocê receberá 100 likes diariamente automaticamente.\n\n⚠️ **Atenção:** Você precisará ser liberado novamente para alterar seu ID.",
                    color=0x00FF00
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                logger.info(f"User {interaction.user} registered FF ID: {ff_id} and was removed from released list")
            else:
                embed = discord.Embed(
                    title="❌ Erro no Cadastro",
                    description=message,
                    color=0xFF0000
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)

        except Exception as e:
            logger.error(f"Error in modal submission: {e}")
            await interaction.response.send_message(
                "❌ Ocorreu um erro interno. Tente novamente mais tarde.",
                ephemeral=True
            )

class RegistrationView(discord.ui.View):
    def __init__(self, button_text, button_color):
        super().__init__(timeout=None)
        self.button_text = button_text
        self.button_color = button_color

        # Map color names to discord.ButtonStyle
        color_map = {
            'primary': discord.ButtonStyle.primary,
            'secondary': discord.ButtonStyle.secondary,
            'success': discord.ButtonStyle.success,
            'danger': discord.ButtonStyle.danger
        }

        button_style = color_map.get(button_color.lower(), discord.ButtonStyle.primary)

        # Create the register button (Colocar ID)
        register_button = discord.ui.Button(
            label=button_text,
            style=button_style,
            custom_id='register_button'
        )
        register_button.callback = self.register_callback
        self.add_item(register_button)

        # Create the access request button (Liberar Acesso)
        access_button = discord.ui.Button(
            label="Liberar Acesso",
            style=discord.ButtonStyle.secondary,
            custom_id='access_button',
            emoji="🔓"
        )
        access_button.callback = self.access_callback
        self.add_item(access_button)

    async def register_callback(self, interaction: discord.Interaction):
        # Check if user is released
        if not bot_config.is_user_released(interaction.user.id):
            embed = discord.Embed(
                title="🔒 Acesso Não Liberado",
                description="Você ainda não foi liberado. Clique primeiro em **Liberar Acesso** para solicitar.",
                color=0xFF0000
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        modal = FreFireIDModal()
        await interaction.response.send_modal(modal)

    async def access_callback(self, interaction: discord.Interaction):
        # Create ticket channel
        guild = interaction.guild
        if not guild:
            await interaction.response.send_message("❌ Este comando só funciona em servidores.", ephemeral=True)
            return

        # Check if user already has a ticket open
        existing_channel = discord.utils.get(guild.channels, name=f"ticket-{interaction.user.id}")
        if existing_channel:
            await interaction.response.send_message(
                f"❌ Você já tem um ticket aberto: {existing_channel.mention}",
                ephemeral=True
            )
            return

        try:
            # Create ticket channel
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(read_messages=False),
                interaction.user: discord.PermissionOverwrite(
                    read_messages=True, 
                    send_messages=True, 
                    attach_files=True, 
                    embed_links=True
                ),
                guild.me: discord.PermissionOverwrite(
                    read_messages=True, 
                    send_messages=True, 
                    attach_files=True, 
                    embed_links=True
                )
            }

            # Add admin permissions
            admin_user = guild.get_member(ADMIN_ID)
            if admin_user:
                overwrites[admin_user] = discord.PermissionOverwrite(
                    read_messages=True, 
                    send_messages=True, 
                    attach_files=True, 
                    embed_links=True
                )

            channel = await guild.create_text_channel(
                f"ticket-{interaction.user.id}",
                overwrites=overwrites,
                category=None
            )

            # Create ticket embed
            embed = discord.Embed(
                title="💳 Pagamento para Liberação de Acesso",
                description=(
                    "O valor para liberar é **R$ 0,50**.\n"
                    "Envie o valor para a chave Pix abaixo e **mande o comprovante (imagem/arquivo) aqui no ticket**.\n"
                    "📎 Você pode anexar imagens e arquivos neste canal.\n"
                    "Após a confirmação pelo administrador, seu acesso será liberado."
                ),
                color=0x00FF00
            )

            # Create ticket view with buttons
            view = TicketView()
            await channel.send(f"{interaction.user.mention}", embed=embed, view=view)

            await interaction.response.send_message(
                f"✅ Ticket criado: {channel.mention}",
                ephemeral=True
            )

            # Schedule auto-delete
            asyncio.create_task(auto_delete_ticket(channel.id, TICKET_AUTO_DELETE_HOURS))

        except Exception as e:
            logger.error(f"Error creating ticket: {e}")
            await interaction.response.send_message(
                "❌ Erro ao criar ticket. Tente novamente.",
                ephemeral=True
            )

# Ticket system classes and functions
class PixKeyModal(discord.ui.Modal, title="Configurar Chave Pix"):
    def __init__(self):
        super().__init__()

    pix_key = discord.ui.TextInput(
        label="Nova Chave Pix",
        placeholder="Digite a nova chave Pix...",
        required=True,
        max_length=100
    )

    async def on_submit(self, interaction: discord.Interaction):
        global PIX_CHAVE
        PIX_CHAVE = self.pix_key.value
        bot_config.set_pix_key(PIX_CHAVE)

        await interaction.response.send_message(
            f"✅ Chave Pix atualizada para: `{PIX_CHAVE}`",
            ephemeral=True
        )

class DescriptionModal(discord.ui.Modal, title="Adicionar Descrição"):
    def __init__(self):
        super().__init__()

    description = discord.ui.TextInput(
        label="Descrição do Ticket",
        placeholder="Digite uma descrição para este ticket...",
        style=discord.TextStyle.paragraph,
        required=True,
        max_length=1000
    )

    async def on_submit(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="📝 Descrição Adicionada",
            description=self.description.value,
            color=0x0099FF,
            timestamp=datetime.utcnow()
        )
        embed.set_author(name=f"Por: {interaction.user.display_name}", icon_url=interaction.user.avatar.url if interaction.user.avatar else None)

        await interaction.response.send_message(embed=embed)

class TicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Ver Chave Pix", style=discord.ButtonStyle.primary, emoji="💳")
    async def pix_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        pix_key = bot_config.get_pix_key()
        await interaction.response.send_message(
            f"🔑 **Chave Pix:** `{pix_key}`\n\nCopie esta chave para fazer o pagamento de R$ 0,50",
            ephemeral=True
        )

    @discord.ui.button(label="Colocar Descrição", style=discord.ButtonStyle.secondary, emoji="📝")
    async def description_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check if user is admin
        if interaction.user.id != ADMIN_ID:
            if not interaction.guild:
                await interaction.response.send_message("❌ Apenas administradores podem usar este botão.", ephemeral=True)
                return

            member = interaction.guild.get_member(interaction.user.id)
            if not member or not member.guild_permissions.administrator:
                await interaction.response.send_message("❌ Apenas administradores podem usar este botão.", ephemeral=True)
                return

        modal = DescriptionModal()
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Fechar Ticket", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def close_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("🗑️ Fechando ticket em 3 segundos...")
        await asyncio.sleep(3)
        if hasattr(interaction.channel, 'delete'):
            await interaction.channel.delete()

    @discord.ui.button(label="Configurar Chave Pix", style=discord.ButtonStyle.success, emoji="⚙️")
    async def config_pix_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Check if user is admin
        if interaction.user.id != ADMIN_ID:
            if not interaction.guild:
                await interaction.response.send_message("❌ Apenas administradores podem usar este botão.", ephemeral=True)
                return

            member = interaction.guild.get_member(interaction.user.id)
            if not member or not member.guild_permissions.administrator:
                await interaction.response.send_message("❌ Apenas administradores podem usar este botão.", ephemeral=True)
                return

        modal = PixKeyModal()
        await interaction.response.send_modal(modal)

async def auto_delete_ticket(channel_id, hours):
    """Auto delete ticket after specified hours"""
    await asyncio.sleep(hours * 3600)  # Convert hours to seconds

    try:
        channel = bot.get_channel(channel_id)
        if channel and hasattr(channel, 'name') and channel.name.startswith("ticket-"):
            if hasattr(channel, 'send'):
                await channel.send("⏰ Este ticket será fechado automaticamente em 30 segundos por inatividade.")
            await asyncio.sleep(30)
            if hasattr(channel, 'delete'):
                await channel.delete()
                logger.info(f"Auto-deleted ticket channel {channel_id}")
    except Exception as e:
        logger.error(f"Error auto-deleting ticket {channel_id}: {e}")

@bot.event
async def on_ready():
    logger.info(f'{bot.user} has connected to Discord!')

    # Log current registrations count
    registrations = registration_data.get_all_registrations()
    logger.info(f"Bot loaded with {len(registrations)} registered users")

    # Start the daily likes task
    if not daily_likes_task.is_running():
        daily_likes_task.start()

    # Sync slash commands
    try:
        synced = await bot.tree.sync()
        logger.info(f"Synced {len(synced)} command(s)")
    except Exception as e:
        logger.error(f"Failed to sync commands: {e}")

@bot.tree.command(name="botlike", description="Cria um painel de cadastro de ID do Free Fire (Admin apenas)")
async def botlike(
    interaction: discord.Interaction,
    titulo: str,
    descricao: str,
    cor_hex: str = "#0099FF",
    cor_botao: str = "primary",
    texto_botao: str = "Cadastrar ID",
    imagem_url: str = ""
):
    # Check if user is admin (specific user ID or server admin)
    AUTHORIZED_ADMIN_ID = 794343189896232971  # Seu ID específico

    try:
        if interaction.user.id != AUTHORIZED_ADMIN_ID:
            if not interaction.guild:
                await interaction.response.send_message(
                    "❌ Este comando só pode ser usado em servidores.",
                    ephemeral=True
                )
                return

            member = interaction.guild.get_member(interaction.user.id)
            if not member or not member.guild_permissions.administrator:
                await interaction.response.send_message(
                    "❌ Você precisa ser administrador para usar este comando.",
                    ephemeral=True
                )
                return
    except Exception as e:
        logger.error(f"Error checking permissions: {e}")
        return

    try:
        # Validate hex color
        if not cor_hex.startswith('#'):
            cor_hex = '#' + cor_hex

        # Convert hex to int
        try:
            color_int = int(cor_hex.replace('#', ''), 16)
        except ValueError:
            if not interaction.response.is_done():
                await interaction.response.send_message(
                    "❌ Cor hexadecimal inválida. Use o formato #FF0000",
                    ephemeral=True
                )
            return

        # Validate button color
        valid_colors = ['primary', 'secondary', 'success', 'danger']
        if cor_botao.lower() not in valid_colors:
            if not interaction.response.is_done():
                await interaction.response.send_message(
                    f"❌ Cor do botão deve ser uma das opções: {', '.join(valid_colors)}",
                    ephemeral=True
                )
            return

        # Create embed
        embed = discord.Embed(
            title=titulo,
            description=descricao,
            color=color_int
        )

        if imagem_url and imagem_url.strip():
            embed.set_image(url=imagem_url)

        embed.set_footer(text="Clique no botão abaixo para cadastrar seu ID do Free Fire")

        # Create view with button
        view = RegistrationView(texto_botao, cor_botao)

        if not interaction.response.is_done():
            await interaction.response.send_message(embed=embed, view=view)
            logger.info(f"Admin {interaction.user} created registration panel")

    except Exception as e:
        logger.error(f"Error in botlike command: {e}")
        if not interaction.response.is_done():
            try:
                await interaction.response.send_message(
                    "❌ Ocorreu um erro ao criar o painel.",
                    ephemeral=True
                )
            except:
                pass

@bot.tree.command(name="configcanal", description="Define o canal onde as notificações diárias serão enviadas (Admin apenas)")
async def configcanal(interaction: discord.Interaction, canal: discord.TextChannel):
    # Check if user is admin (specific user ID or server admin)
    AUTHORIZED_ADMIN_ID = 794343189896232971  # Seu ID específico

    try:
        if interaction.user.id != AUTHORIZED_ADMIN_ID:
            if not interaction.guild:
                await interaction.response.send_message(
                    "❌ Este comando só pode ser usado em servidores.",
                    ephemeral=True
                )
                return

            member = interaction.guild.get_member(interaction.user.id)
            if not member or not member.guild_permissions.administrator:
                await interaction.response.send_message(
                    "❌ Você precisa ser administrador para usar este comando.",
                    ephemeral=True
                )
                return
    except Exception as e:
        logger.error(f"Error checking permissions: {e}")
        return

    try:
        # Set the notification channel
        bot_config.set_notification_channel(canal.id)

        embed = discord.Embed(
            title="✅ Canal Configurado",
            description=f"O canal {canal.mention} foi definido como canal de notificações diárias.\n\nTodos os relatórios de likes automáticos serão enviados aqui.",
            color=0x00FF00
        )

        if not interaction.response.is_done():
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Admin {interaction.user} set notification channel to {canal.name} ({canal.id})")

    except Exception as e:
        logger.error(f"Error in configcanal command: {e}")
        if not interaction.response.is_done():
            try:
                await interaction.response.send_message(
                    "❌ Ocorreu um erro ao configurar o canal.",
                    ephemeral=True
                )
            except:
                pass

async def clear_bot_cache():
    """Clear bot cache without affecting saved data"""
    try:
        import gc

        # Simple efficient garbage collection
        collected = gc.collect()

        # Clear temporary variables
        locals().clear()

        # Final collection
        final_collected = gc.collect()
        total_collected = collected + final_collected

        logger.info(f"Cache cleared: {total_collected} objects freed")
        return True

    except Exception as e:
        logger.error(f"Error clearing bot cache: {e}")
        return False

@bot.tree.command(name="limparcache", description="Limpa o cache do bot sem afetar dados salvos (Admin apenas)")
async def limparcache(interaction: discord.Interaction):
    # Check if user is admin (specific user ID or server admin)
    AUTHORIZED_ADMIN_ID = 794343189896232971  # Seu ID específico

    try:
        if interaction.user.id != AUTHORIZED_ADMIN_ID:
            if not interaction.guild:
                await interaction.response.send_message(
                    "❌ Este comando só pode ser usado em servidores.",
                    ephemeral=True
                )
                return

            member = interaction.guild.get_member(interaction.user.id)
            if not member or not member.guild_permissions.administrator:
                await interaction.response.send_message(
                    "❌ Você precisa ser administrador para usar este comando.",
                    ephemeral=True
                )
                return
    except Exception as e:
        logger.error(f"Error checking permissions: {e}")
        return

    try:
        await interaction.response.defer(ephemeral=True)

        # Clear cache
        success = await clear_bot_cache()

        # Check that saved data is still intact
        registrations_count = len(registration_data.get_all_registrations())
        config_channel = bot_config.get_notification_channel()

        embed = discord.Embed(
            title="🧹 Limpeza de Cache",
            color=0x00FF00 if success else 0xFF0000
        )

        embed.add_field(
            name="Status",
            value="✅ Cache limpo com sucesso" if success else "❌ Erro ao limpar cache",
            inline=False
        )

        embed.add_field(
            name="Dados Preservados",
            value=f"📊 {registrations_count} IDs cadastrados\n🔔 Canal: {'Configurado' if config_channel else 'Não configurado'}",
            inline=False
        )

        if success:
            embed.add_field(
                name="Limpeza Realizada",
                value="• Cache de usuários limpo\n• Cache de guilds otimizado\n• Memória liberada\n• Dados dos IDs preservados",
                inline=False
            )

        await interaction.followup.send(embed=embed, ephemeral=True)
        logger.info(f"Admin {interaction.user} cleared bot cache")

    except Exception as e:
        logger.error(f"Error in limparcache command: {e}")
        try:
            await interaction.followup.send(
                "❌ Ocorreu um erro ao limpar o cache.",
                ephemeral=True
            )
        except:
            pass

@bot.tree.command(name="testeapi", description="Testa a API com um ID específico para ver as informações retornadas (Admin apenas)")
async def testeapi(interaction: discord.Interaction, ff_id: str):
    # Check if user is admin (specific user ID or server admin)
    AUTHORIZED_ADMIN_ID = 794343189896232971  # Seu ID específico

    try:
        if interaction.user.id != AUTHORIZED_ADMIN_ID:
            if not interaction.guild:
                await interaction.response.send_message(
                    "❌ Este comando só pode ser usado em servidores.",
                    ephemeral=True
                )
                return

            member = interaction.guild.get_member(interaction.user.id)
            if not member or not member.guild_permissions.administrator:
                await interaction.response.send_message(
                    "❌ Você precisa ser administrador para usar este comando.",
                    ephemeral=True
                )
                return
    except Exception as e:
        logger.error(f"Error checking permissions: {e}")
        return

    await interaction.response.defer(ephemeral=True)

    try:
        success, message, api_data = await send_likes_to_api(ff_id)

        embed = discord.Embed(
            title="🧪 Teste da API",
            color=0x0099FF if success else 0xFF0000
        )

        embed.add_field(
            name="Status",
            value="✅ Sucesso" if success else "❌ Erro",
            inline=True
        )

        embed.add_field(
            name="ID Testado",
            value=ff_id,
            inline=True
        )

        embed.add_field(
            name="Mensagem",
            value=message,
            inline=False
        )

        if api_data:
            # Show the complete API response
            api_text = json.dumps(api_data, indent=2, ensure_ascii=False)
            if len(api_text) > 1000:
                api_text = api_text[:1000] + "..."

            embed.add_field(
                name="Dados da API",
                value=f"```json\n{api_text}\n```",
                inline=False
            )

        await interaction.followup.send(embed=embed, ephemeral=True)
        logger.info(f"Admin {interaction.user} tested API with FF ID: {ff_id}")

    except Exception as e:
        logger.error(f"Error in testeapi command: {e}")
        try:
            await interaction.followup.send(
                "❌ Ocorreu um erro ao testar a API.",
                ephemeral=True
            )
        except:
            pass

@bot.tree.command(name="liberar", description="Libera o acesso de um usuário para usar o bot (Admin apenas)")
async def liberar(interaction: discord.Interaction, usuario: discord.Member):
    # Check if user is admin
    if interaction.user.id != ADMIN_ID:
        if not interaction.guild:
            await interaction.response.send_message(
                "❌ Este comando só pode ser usado em servidores.",
                ephemeral=True
            )
            return

        member = interaction.guild.get_member(interaction.user.id)
        if not member or not member.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ Você precisa ser administrador para usar este comando.",
                ephemeral=True
            )
            return

    try:
        # Add user to released users list
        bot_config.add_released_user(usuario.id)

        embed = discord.Embed(
            title="✅ Usuário Liberado",
            description=f"O usuário {usuario.mention} foi liberado com sucesso!\n\nAgora ele pode usar o botão **Colocar ID** para cadastrar seu Free Fire ID.",
            color=0x00FF00
        )

        await interaction.response.send_message(embed=embed, ephemeral=True)
        logger.info(f"Admin {interaction.user} released user {usuario} ({usuario.id})")

        # Send DM to released user
        try:
            dm_embed = discord.Embed(
                title="🎉 Acesso Liberado!",
                description="Seu acesso foi liberado! Agora você pode cadastrar seu ID do Free Fire no painel do servidor.",
                color=0x00FF00
            )
            await usuario.send(embed=dm_embed)
        except:
            # If DM fails, just continue
            pass

    except Exception as e:
        logger.error(f"Error in liberar command: {e}")
        try:
            await interaction.response.send_message(
                "❌ Ocorreu um erro ao liberar o usuário.",
                ephemeral=True
            )
        except:
            pass

async def send_likes_to_api(ff_id: str) -> tuple:
    """Send 100 likes to a Free Fire ID via API and return response info"""
    try:
        url = f"{API_BASE_URL}?uid={ff_id}&amount_of_likes=100&auth={API_AUTH_TOKEN}"

        timeout = aiohttp.ClientTimeout(total=30)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(url) as response:
                response_text = await response.text()

                if response.status == 200:
                    try:
                        # Try to parse JSON response to get player info
                        response_data = json.loads(response_text)
                        return True, "Likes enviados com sucesso", response_data
                    except json.JSONDecodeError:
                        # If not JSON, return the text response
                        return True, f"Likes enviados com sucesso - {response_text}", None
                else:
                    return False, f"Erro HTTP {response.status}: {response_text}", None

    except asyncio.TimeoutError:
        return False, "Timeout na requisição", None
    except Exception as e:
        return False, f"Erro na requisição: {str(e)}", None

@tasks.loop(hours=24)
async def daily_likes_task():
    """Task that runs every 24 hours to send likes"""
    logger.info("Starting daily likes task")

    # Clear cache before processing to ensure optimal performance
    logger.info("Clearing bot cache before daily task...")
    cache_cleared = await clear_bot_cache()
    if cache_cleared:
        logger.info("Cache cleared successfully before daily task")

    registrations = registration_data.get_all_registrations()

    if not registrations:
        logger.info("No registrations found, skipping daily likes")
        return

    # Get notification channel from config
    notification_channel_id = bot_config.get_notification_channel()
    if not notification_channel_id:
        logger.warning("No notification channel configured. Use /configcanal to set one.")
        return

    try:
        channel = bot.get_channel(notification_channel_id)
        if not channel:
            logger.error(f"Notification channel {notification_channel_id} not found")
            return

        # Ensure it's a text-sendable channel
        if not hasattr(channel, 'send'):
            logger.error(f"Channel {notification_channel_id} is not a text channel")
            return
    except Exception as e:
        logger.error(f"Error getting notification channel: {e}")
        return

    results = []

    for user_id, ff_ids_list in registrations.items():
        # Iterate through all IDs registered for the user
        for ff_id in ff_ids_list:
            try:
                user = bot.get_user(int(user_id))
                user_mention = user.mention if user else f"<@{user_id}>"

                success, message, api_data = await send_likes_to_api(ff_id)

                if success:
                    # Format result with API information if available
                    result_text = f"✅ {user_mention} (ID: {ff_id}) - {message}"

                    # Add player information from API response if available
                    if api_data and isinstance(api_data, dict):
                        player_info = []

                        # Common fields that might be in the API response
                        if 'name' in api_data:
                            player_info.append(f"Nome: {api_data['name']}")
                        if 'nickname' in api_data:
                            player_info.append(f"Nick: {api_data['nickname']}")
                        if 'level' in api_data:
                            player_info.append(f"Level: {api_data['level']}")
                        if 'region' in api_data:
                            player_info.append(f"Região: {api_data['region']}")
                        if 'total_likes' in api_data:
                            player_info.append(f"Likes Total: {api_data['total_likes']}")
                        if 'likes_received' in api_data:
                            player_info.append(f"Likes Recebidos: {api_data['likes_received']}")

                        if player_info:
                            result_text += f"\n  📊 {' | '.join(player_info)}"

                    results.append(result_text)
                    logger.info(f"Successfully sent likes to FF ID: {ff_id} for user {user_id}")
                else:
                    results.append(f"❌ {user_mention} (ID: {ff_id}) - Erro: {message}")
                    logger.error(f"Failed to send likes to FF ID {ff_id} for user {user_id}: {message}")

                # Small delay between requests to avoid rate limiting
                await asyncio.sleep(1)

            except Exception as e:
                results.append(f"❌ ID {ff_id} (User: {user_id}) - Erro interno: {str(e)}")
                logger.error(f"Error processing FF ID {ff_id} for user {user_id}: {e}")

    # Send results to notification channel
    try:
        embed = discord.Embed(
            title="📊 Relatório Diário de Likes",
            description=f"Resultado do envio automático de likes ({datetime.now().strftime('%d/%m/%Y %H:%M')})",
            color=0x0099FF
        )

        # Split results into chunks if too long
        result_text = "\n".join(results)
        if len(result_text) > 4000:
            # Send results in multiple embeds
            chunks = [results[i:i+10] for i in range(0, len(results), 10)]
            for i, chunk in enumerate(chunks):
                chunk_embed = discord.Embed(
                    title=f"📊 Relatório Diário de Likes (Parte {i+1}/{len(chunks)})",
                    description="\n".join(chunk),
                    color=0x0099FF
                )
                await channel.send(embed=chunk_embed)  # type: ignore
        else:
            embed.description = embed.description + f"\n\n{result_text}" if embed.description else result_text
            await channel.send(embed=embed)  # type: ignore

        logger.info(f"Daily likes report sent to channel {notification_channel_id}")

        # Clear cache after completing daily task
        logger.info("Clearing bot cache after daily task completion...")
        cache_cleared = await clear_bot_cache()
        if cache_cleared:
            logger.info("Cache cleared successfully after daily task")

    except Exception as e:
        logger.error(f"Error sending daily report: {e}")

        # Clear cache even if there was an error, to ensure clean state
        try:
            logger.info("Clearing bot cache after task error...")
            await clear_bot_cache()
        except:
            pass

@daily_likes_task.before_loop
async def before_daily_likes():
    await bot.wait_until_ready()

    # Calculate next run time (daily at a specific hour, e.g., 10:00)
    now = datetime.now()
    next_run = now.replace(hour=10, minute=0, second=0, microsecond=0)

    # If it's past 10:00 today, schedule for tomorrow
    if now.hour >= 10:
        next_run += timedelta(days=1)

    # Wait until the scheduled time
    wait_seconds = (next_run - now).total_seconds()
    logger.info(f"Daily likes task scheduled for {next_run}, waiting {wait_seconds} seconds")
    await asyncio.sleep(wait_seconds)

@bot.event
async def on_error(event, *args, **kwargs):
    logger.error(f"An error occurred in event {event}", exc_info=True)

if __name__ == "__main__":
    try:
        bot.run(BOT_TOKEN)
    except Exception as e:
        logger.error(f"Failed to start bot: {e}")